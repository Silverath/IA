# coding=utf-8
import Circuito
import AG

#Ejecutamos el main() de la clase AG.py
AG.mainAG()
