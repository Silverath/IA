import warnings
import matplotlib.pyplot as dibuj
from AG import *

warnings.filterwarnings(action='ignore')

colores_nodos = enfriamiento_simulado(100, 0.95, 100, 1000)

nx.draw(g, with_labels=True, node_color=colores_nodos)

print('Para el grafo representado en pantalla, se ha llegado a la conclusión que un coloreado óptimo es el siguiente:\n' + str(colores_nodos) + '\ndonde el valor indica el color en la lista y el índice indica el vértice correspondiene en el grafo.')

if len(set(colores_nodos)) > 3:
    print('Como se puede observar en la imagen, no ha sido posible colorear el grafo utilizando únicamente 3 colores, '
          'en su lugar se han utilizado ' + str(len(set(colores_nodos))))
else:
    print('Se han utilizado 3 colores para el grafo mostrado en la imagen.')

dibuj.show()

print('Número de aristas: ' + str(g.number_of_edges()))