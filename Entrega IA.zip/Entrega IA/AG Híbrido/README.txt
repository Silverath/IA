Este proyecto ha sido realizado por Antonio Manuel Monta�o Aguilera y Pablo Mart�nez Figueroa en el contexto de desarrollo de un proyecto
para la asignatura Inteligencia Artificial, perteneciente al Departamento de Ciencias de la Computaci�n e Inteligencia Artificial de la
Escuela T�cnica Superior de Ingenier�a Inform�tica de la Universidad de Sevilla.

El proyecto trata sobre implementar un algoritmo gen�tico para colorear grafos, cambiando la fase de mutaci�n por una fase de enfriamiento
simulado, creando un algoritmo gen�tico h�brido.

El proyecto se divide en 3 archivos principales:
	- AG.py donde se define cada uno de los m�todos que intervienen en el algoritmo.
	- M�todos auxiliares.py donde, tal y como su nombre indica, se definen varios m�todos que se usan en AG.py.
	- Main.py, donde se ejecuta el algoritmo y se realizan las pruebas.

Para ejecutar el programa, habr� que iniciar el archivo Main.py. Tras ejecutarlo, se le pedir� al usuario un n�mero de v�rtices que
compondr�n el grafo. Adem�s, se le pedir� la probabilidad de que haya conexi�n entre dichos v�rtices, siendo 0 ninguna posibilidad y 1 
posibilidad total, formando un grafo k-completo. Tambi�n se sugiere un tama�o de poblaci�n, el cual sugerimos que sea mayor de 100000, pues
as� el programa tendr� bastantes individuos con los que trabajar y tendr� muchas m�s posibilidades de sacar un buen coloreado.